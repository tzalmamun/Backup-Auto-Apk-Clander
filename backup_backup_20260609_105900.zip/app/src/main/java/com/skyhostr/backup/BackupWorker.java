package com.skyhostr.backup;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import android.provider.Settings;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import java.io.File;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Response;

public class BackupWorker extends Worker {
    private Context context;

    public BackupWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
        this.context = context;
    }

    @NonNull
    @Override
    public Result doWork() {
        SharedPreferences pref = context.getSharedPreferences("SkyConfig", Context.MODE_PRIVATE);
        if (!pref.getBoolean("is_upload_on", true)) return Result.success();

        String folderInput = pref.getString("selected_folders", "DCIM/Screenshots");
        String[] folderNames = folderInput.split(",");

        for (String fName : folderNames) {
            File folder = new File(Environment.getExternalStorageDirectory(), fName.trim());
            if (folder.exists() && folder.isDirectory()) {
                File[] files = folder.listFiles();
                if (files != null) {
                    for (File file : files) {
                        if (file.isFile() && isImage(file)) {
                            uploadFile(file);
                        }
                    }
                }
            }
        }
        return Result.success();
    }

    private boolean isImage(File file) {
        String name = file.getName().toLowerCase();
        return name.endsWith(".jpg") || name.endsWith(".png") || name.endsWith(".jpeg") || name.endsWith(".webp");
    }

    private void uploadFile(File file) {
        try {
            String deviceId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
            String fileHash = FileUtils.getFileHash(file); // ফাইলের ইউনিক কোড

            RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), file);
            MultipartBody.Part body = MultipartBody.Part.createFormData("file", file.getName(), requestFile);
            
            RequestBody devId = RequestBody.create(MediaType.parse("text/plain"), deviceId);
            RequestBody action = RequestBody.create(MediaType.parse("text/plain"), "upload");
            RequestBody hash = RequestBody.create(MediaType.parse("text/plain"), fileHash);

            ApiService apiService = RetrofitClient.getClient(context).create(ApiService.class);
            apiService.uploadFile(body, devId, action, hash).execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}