package com.skyhostr.backup;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

public interface ApiService {
    @Multipart
    @POST("api.php")
    Call<ResponseBody> uploadFile(
            @Part MultipartBody.Part file,
            @Part("device_id") RequestBody deviceId,
            @Part("action") RequestBody action,
            @Part("hash") RequestBody hash // ডুপ্লিকেট চেক করার হ্যাশ
    );

    @POST("api.php")
    Call<ResponseBody> checkConnection(@Query("action") String action);

    @FormUrlEncoded
    @POST("api.php")
    Call<ResponseBody> deleteFile(
            @Field("action") String action,
            @Field("file_name") String fileName
    );
}