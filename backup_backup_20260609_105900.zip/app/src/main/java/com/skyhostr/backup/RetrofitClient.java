package com.skyhostr.backup;

import android.content.Context;
import android.content.SharedPreferences;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {
    private static Retrofit retrofit = null;

    public static Retrofit getClient(Context context) {
        SharedPreferences pref = context.getSharedPreferences("SkyConfig", Context.MODE_PRIVATE);
        String baseUrl = pref.getString("server_url", "https://google.com/"); 

        if (retrofit == null || !retrofit.baseUrl().toString().equals(baseUrl)) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }
}