package com.skyhostr.backup;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;

public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.ViewHolder> {
    private List<String> imagePaths;
    private Context context;
    private boolean isCloud;

    public ImageAdapter(Context context, List<String> imagePaths, boolean isCloud) {
        this.context = context;
        this.imagePaths = imagePaths;
        this.isCloud = isCloud;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_image, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String path = imagePaths.get(position);
        
        // যদি ক্লাউড হয় তবে ডোমেইন লিঙ্ক যোগ হবে
        if (isCloud) {
            // SharedPreferences থেকে ডোমেইন নিয়ে এখানে লিঙ্ক তৈরি করুন
        }

        Glide.with(context).load(path).into(holder.imageView);
    }

    @Override
    public int getItemCount() { return imagePaths.size(); }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
        }
    }
}