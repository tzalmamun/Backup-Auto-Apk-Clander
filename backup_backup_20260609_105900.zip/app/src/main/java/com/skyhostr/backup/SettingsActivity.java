package com.skyhostr.backup;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.util.concurrent.TimeUnit;

public class SettingsActivity extends AppCompatActivity {

    private EditText etUrl, etFolders, etInterval, etMbLimit;
    private SwitchCompat swAutoUpload, swWifiOnly;
    private Button btnSave, btnAdmin, btnPresets, btnGithub;
    private SharedPreferences pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // UI কম্পোনেন্ট আইডি সেটআপ
        etUrl = findViewById(R.id.etUrl);
        etFolders = findViewById(R.id.etFolders);
        etInterval = findViewById(R.id.etInterval);
        etMbLimit = findViewById(R.id.etMbLimit);
        swAutoUpload = findViewById(R.id.swAutoUpload);
        swWifiOnly = findViewById(R.id.swWifiOnly);
        btnSave = findViewById(R.id.btnSave);
        btnAdmin = findViewById(R.id.btnAdmin);
        btnPresets = findViewById(R.id.btnAddPresets);
        btnGithub = findViewById(R.id.btnGithub); // গিটহাব বাটন

        pref = getSharedPreferences("SkyConfig", MODE_PRIVATE);

        // ১. আগের সেটিংস লোড করা
        loadSettings();

        // ২. ক্যামেরা প্রিসেট বাটন (মটোরোলা, শাওমি, পিক্সেল ইত্যাদি)
        btnPresets.setOnClickListener(v -> {
            String paths = "DCIM/Camera, DCIM/Screenshots, Pictures/Screenshots, Pictures/Camera, Motorola/Camera";
            etFolders.setText(paths);
            Toast.makeText(this, "Camera Paths Added!", Toast.LENGTH_SHORT).show();
        });

        // ৩. আনইনস্টল প্রোটেকশন (Admin Permission)
        btnAdmin.setOnClickListener(v -> {
            ComponentName component = new ComponentName(this, MyAdminReceiver.class);
            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component);
            intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Admin permission protects your data.");
            startActivity(intent);
        });

        // ৪. গিটহাব লিংক বাটন (GitHub Link)
        btnGithub.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse("https://github.com/tzalmamun/Backup-Auto-Apk-Clander"));
            startActivity(i);
        });

        // ৫. সেভ বাটন
        btnSave.setOnClickListener(v -> saveSettings());
    }

    private void loadSettings() {
        etUrl.setText(pref.getString("server_url", ""));
        etFolders.setText(pref.getString("selected_folders", "DCIM/Screenshots"));
        etInterval.setText(String.valueOf(pref.getInt("sync_hours", 1)));
        etMbLimit.setText(String.valueOf(pref.getLong("mb_limit", 100)));
        swAutoUpload.setChecked(pref.getBoolean("is_upload_on", true));
        swWifiOnly.setChecked(pref.getBoolean("wifi_only", false));
    }

    private void saveSettings() {
        String url = etUrl.getText().toString().trim();
        String folders = etFolders.getText().toString().trim();
        String intervalStr = etInterval.getText().toString().trim();

        if (url.isEmpty()) {
            Toast.makeText(this, "Enter Server URL", Toast.LENGTH_SHORT).show();
            return;
        }

        // URL Clean (api.php থাকলে তা মুছে ফেলা)
        if (url.contains("api.php")) url = url.replace("api.php", "");
        if (!url.endsWith("/")) url += "/";

        int interval = intervalStr.isEmpty() ? 1 : Integer.parseInt(intervalStr);
        long mbLimit = Long.parseLong(etMbLimit.getText().toString());

        SharedPreferences.Editor editor = pref.edit();
        editor.putString("server_url", url);
        editor.putString("selected_folders", folders);
        editor.putInt("sync_hours", interval);
        editor.putLong("mb_limit", mbLimit);
        editor.putBoolean("is_upload_on", swAutoUpload.isChecked());
        editor.putBoolean("wifi_only", swWifiOnly.isChecked());
        editor.apply();

        // ব্যাকগ্রাউন্ড ওয়ার্কার রি-শিডিউল করা
        if (swAutoUpload.isChecked()) {
            setupBackupJob(interval, swWifiOnly.isChecked());
        } else {
            WorkManager.getInstance(this).cancelUniqueWork("SkyBackupJob");
        }

        Toast.makeText(this, "All Settings Saved!", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void setupBackupJob(int hours, boolean wifiOnly) {
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(wifiOnly ? NetworkType.UNMETERED : NetworkType.CONNECTED)
                .build();

        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(
                BackupWorker.class, hours, TimeUnit.HOURS)
                .setConstraints(constraints)
                .build();

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "SkyBackupJob",
                ExistingPeriodicWorkPolicy.REPLACE,
                request
        );
    }
}