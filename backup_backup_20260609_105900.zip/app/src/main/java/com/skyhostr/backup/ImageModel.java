package com.skyhostr.backup;

public class ImageModel {
    String path, time, location;
    public ImageModel(String path, String time, String location) {
        this.path = path;
        this.time = time;
        this.location = location;
    }
}