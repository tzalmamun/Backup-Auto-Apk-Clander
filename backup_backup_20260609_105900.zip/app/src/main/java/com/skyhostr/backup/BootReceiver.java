package com.skyhostr.backup;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.util.concurrent.TimeUnit;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            // রিস্টার্টের পর আবার ১২ ঘণ্টার লুপ সেট করা
            PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(
                    BackupWorker.class, 12, TimeUnit.HOURS)
                    .setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                    .build();
            WorkManager.getInstance(context).enqueueUniquePeriodicWork("SkySyncJob", ExistingPeriodicWorkPolicy.KEEP, request);
        }
    }
}