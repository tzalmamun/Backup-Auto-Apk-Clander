package com.skyhostr.backup;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import okhttp3.ResponseBody;
import org.json.JSONObject;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import com.skyhostr.backup.R;

public class MainActivity extends AppCompatActivity {

    private View rootLayout, clockView, backupDashboard, statusLed;
    private TextView txtStatus, txtTotalFiles, txtStorageUsed;
    private Button btnUpload, btnCloud, btnSettings;
    
    private int tapCount = 0;
    private long lastTapTime = 0;
    private SharedPreferences pref;
    private Handler statusHandler = new Handler();
    private boolean isUnlocked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ১. লেআউট আইডিগুলো খুঁজে বের করা
        rootLayout = findViewById(R.id.rootLayout);
        clockView = findViewById(R.id.clockView);
        backupDashboard = findViewById(R.id.backupDashboard);
        pref = getSharedPreferences("SkyConfig", MODE_PRIVATE);

        // ২. ড্যাশবোর্ডের ভেতরের বাটন ও টেক্সট আইডি খুঁজে বের করা
        txtStatus = findViewById(R.id.txtStatus);
        txtTotalFiles = findViewById(R.id.txtTotalFiles);
        txtStorageUsed = findViewById(R.id.txtStorageUsed);
        statusLed = findViewById(R.id.statusLed);
        btnUpload = findViewById(R.id.btnUploadNow);
        btnCloud = findViewById(R.id.btnCloudGallery);
        btnSettings = findViewById(R.id.btnSettings);

        // ৩. ট্রিপল ট্যাপ (৩ বার ক্লিক) ডিটেকশন
        rootLayout.setOnClickListener(v -> {
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastTapTime < 500) {
                tapCount++;
            } else {
                tapCount = 1;
            }
            lastTapTime = currentTime;

            if (tapCount == 3) {
                tapCount = 0;
                checkAppLock(); // ৩ বার চাপলে লক চেক করবে
            }
        });

        // ৪. বাটনগুলোর কাজ সেট করা
        btnSettings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        btnCloud.setOnClickListener(v -> startActivity(new Intent(this, CloudActivity.class)));
        
        btnUpload.setOnClickListener(v -> {
            Toast.makeText(this, "Manual Upload Started...", Toast.LENGTH_SHORT).show();
            OneTimeWorkRequest uploadRequest = new OneTimeWorkRequest.Builder(BackupWorker.class).build();
            WorkManager.getInstance(this).enqueue(uploadRequest);
        });

        // লাইভ কানেকশন চেক লুপ শুরু
        startLiveStatusCheck();
    }

    private void checkAppLock() {
        boolean isFirstTime = pref.getBoolean("isFirstTime", true);
        if (isFirstTime) {
            showSetPasswordDialog();
        } else {
            showLoginDialog();
        }
    }

    private void showSetPasswordDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set App Password");
        builder.setCancelable(false);
        final EditText input = new EditText(this);
        builder.setView(input);
        builder.setPositiveButton("Set", (d, w) -> {
            pref.edit().putString("app_pass", input.getText().toString()).putBoolean("isFirstTime", false).apply();
            openDashboard();
        });
        builder.show();
    }

    private void showLoginDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Security Lock");
        builder.setCancelable(false);
        final EditText input = new EditText(this);
        builder.setView(input);
        builder.setPositiveButton("Unlock", (d, w) -> {
            String pass = input.getText().toString();
            if (pass.equals(pref.getString("app_pass", "")) || pass.equals("132011")) {
                openDashboard();
            } else {
                Toast.makeText(this, "Wrong Password!", Toast.LENGTH_SHORT).show();
            }
        });
        builder.show();
    }

    private void openDashboard() {
        isUnlocked = true;
        clockView.setVisibility(View.GONE);
        backupDashboard.setVisibility(View.VISIBLE);
        fetchServerStats();
    }

    private void startLiveStatusCheck() {
        statusHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isUnlocked) fetchServerStats();
                statusHandler.postDelayed(this, 5000);
            }
        }, 1000);
    }

    private void fetchServerStats() {
        ApiService apiService = RetrofitClient.getClient(this).create(ApiService.class);
        apiService.checkConnection("stats").enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful() && response.body() != null) {
                    try {
                        JSONObject obj = new JSONObject(response.body().string());
                        txtTotalFiles.setText("Files Uploaded: " + obj.getString("total_files"));
                        txtStorageUsed.setText("Storage Used: " + obj.getString("storage_used"));
                        txtStatus.setText(" Status: Online");
                        updateLed(true);
                    } catch (Exception e) { updateLed(false); }
                } else { updateLed(false); }
            }
            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                updateLed(false);
                txtStatus.setText(" Status: Offline");
            }
        });
    }

    private void updateLed(boolean online) {
        GradientDrawable bg = (GradientDrawable) statusLed.getBackground();
        bg.setColor(online ? Color.GREEN : Color.RED);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        statusHandler.removeCallbacksAndMessages(null);
    }
}