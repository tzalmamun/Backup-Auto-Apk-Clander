package com.skyhostr.backup;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import okhttp3.ResponseBody;
import org.json.JSONArray;
import org.json.JSONObject;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import java.util.ArrayList;

public class CloudActivity extends AppCompatActivity {

    private ListView listView;
    private ArrayList<String> displayList; // নাম ও সাইজ দেখানোর জন্য
    private ArrayList<String> fileNames;   // শুধু ফাইলের নাম (ডিলিট করার জন্য)
    private ArrayList<String> fileUrls;    // ফাইলের লিঙ্ক (ভিউ করার জন্য)
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cloud);

        listView = findViewById(R.id.listView);
        displayList = new ArrayList<>();
        fileNames = new ArrayList<>();
        fileUrls = new ArrayList<>();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, displayList);
        listView.setAdapter(adapter);

        // ১. ছবিতে ক্লিক করলে ডাইরেক্ট ভিউ হবে
        listView.setOnItemClickListener((parent, view, position, id) -> {
            String url = fileUrls.get(position);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));
            startActivity(intent);
        });

        // ২. ছবিতে চেপে ধরলে (Long Press) ডিলিট অপশন আসবে
        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            String name = fileNames.get(position);
            showDeleteDialog(name, position);
            return true;
        });

        fetchCloudFiles();
    }

    private void fetchCloudFiles() {
        ApiService apiService = RetrofitClient.getClient(this).create(ApiService.class);
        apiService.checkConnection("list").enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    if (response.isSuccessful() && response.body() != null) {
                        String jsonStr = response.body().string();
                        JSONObject jsonObject = new JSONObject(jsonStr);
                        
                        if (jsonObject.getString("status").equals("success")) {
                            JSONArray dataArray = jsonObject.getJSONArray("data");
                            
                            displayList.clear();
                            fileNames.clear();
                            fileUrls.clear();

                            for (int i = 0; i < dataArray.length(); i++) {
                                JSONObject fileObj = dataArray.getJSONObject(i);
                                String name = fileObj.getString("name");
                                String size = fileObj.getString("size");
                                String url = fileObj.getString("url");

                                fileNames.add(name);
                                fileUrls.add(url);
                                displayList.add(name + "\nSize: " + size);
                            }
                            adapter.notifyDataSetChanged();
                        }
                    }
                } catch (Exception e) {
                    Toast.makeText(CloudActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Toast.makeText(CloudActivity.this, "Failed to load files", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showDeleteDialog(final String fileName, final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirm Delete");
        builder.setMessage("Do you want to delete " + fileName + " from server?");
        
        builder.setPositiveButton("Delete", (dialog, which) -> deleteFile(fileName, position));
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void deleteFile(String fileName, final int position) {
        ApiService apiService = RetrofitClient.getClient(this).create(ApiService.class);
        apiService.deleteFile("delete", fileName).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(CloudActivity.this, "File Deleted!", Toast.LENGTH_SHORT).show();
                    displayList.remove(position);
                    fileNames.remove(position);
                    fileUrls.remove(position);
                    adapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(CloudActivity.this, "Delete failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Toast.makeText(CloudActivity.this, "Network Error", Toast.LENGTH_SHORT).show();
            }
        });
    }
}